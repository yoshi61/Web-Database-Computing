var config = { };

config.rootURL = 'localhost:3000/'

config.sessionSecret = 'jjdjfkd335kjhlj353j5'

config.facebook = {
    appId:   '1515461992028115',
    appSecret: '4285059c501053adff18c14bd1e2e403',
    redirectUri: config.rootURL + 'auth/'
};

config.db = {
    host: 'localhost',
    user: 'andrew',
    password: '',
    database: 'ff'
};

module.exports = config;
