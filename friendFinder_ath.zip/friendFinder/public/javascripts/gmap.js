var map;
var markerArray=[];
var infoWindow = new google.maps.InfoWindow({content: "Placeholder"});

function initialize() {

    var mapOptions = {
	center: new google.maps.LatLng(-34.918430, 138.582479),
	zoom: 10
    };
    map = new google.maps.Map(
			  document.getElementById("map-canvas"),
			  mapOptions);
}

function clearMarkers() {
	var markerIndex = 0;
	while (markerIndex < markerArray.length) {
		var checkbox = document.getElementById(markerArray[markerIndex].title);
		if (checkbox.checked == true) {
			markerArray[markerIndex].setMap(map);
		}
		else {
			markerArray[markerIndex].setMap(null);
		}
		++markerIndex;
	}

};

google.maps.event.addDomListener(window, 'load', initialize);
